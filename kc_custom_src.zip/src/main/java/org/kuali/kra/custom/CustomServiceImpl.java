package org.kuali.kra.custom;

public class CustomServiceImpl implements CustomService {
	public void customTest() {
		System.out.println("custom service");
	}

}

package org.kuali.kra.custom;

import org.kuali.rice.kns.web.struts.form.KualiForm;


public class CustomForm extends KualiForm  {

}

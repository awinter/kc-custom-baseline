package org.kuali.kra.custom;

public interface CustomService {
	public void customTest();

}
